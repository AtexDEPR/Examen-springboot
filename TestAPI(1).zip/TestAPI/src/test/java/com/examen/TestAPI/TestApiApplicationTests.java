package com.examen.TestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
